import { useEffect, useState } from "react";
import "./assets/App.css";
import { NAVIGATION } from "./assets/constants";
import { clearCache } from "./assets/cache";
import { Alert } from "./components/ui";
import AccountMenu from "./components/AccountMenu";
import NavigationIcon from "./components/NavigationIcon";
import AuthScreen from "./pages/AuthScreen";
import ChatPage from "./pages/ChatPage";
import CompaniesPage from "./pages/CompaniesPage";
import CompanySettingsPage from "./pages/CompanySettingsPage";
import DatabaseTypesPage from "./pages/DatabaseTypesPage";
import EmployeesPage from "./pages/EmployeesPage";
import ModelsPage from "./pages/ModelsPage";
import ReportsDashboard from "./pages/ReportsDashboard";

const readUser = () => { try { return JSON.parse(sessionStorage.getItem("rubani_user")) || null; } catch { return null; } };

function App() {
  const [user, setUser] = useState(readUser);
  const [activePage, setActivePage] = useState("");
  const [messages, setMessages] = useState([]);
  const [chatCompanyId, setChatCompanyId] = useState("");
  const [expiredMessage, setExpiredMessage] = useState("");

  const resetWorkspace = () => (setMessages([]), setChatCompanyId(""), setActivePage(""));

  function handleAuthenticated(result) {
    clearCache();
    sessionStorage.setItem("rubani_user", JSON.stringify(result));
    setUser(result);
    setExpiredMessage("");
    resetWorkspace();
  }

  function handleLogout(message = "") {
    clearCache();
    sessionStorage.removeItem("rubani_user");
    setUser(null);
    setExpiredMessage(message);
    resetWorkspace();
  }

  useEffect(() => {
    const onExpired = () => handleLogout("Your session has expired. Please log in again.");
    window.addEventListener("rubani:session-expired", onExpired);
    return () => window.removeEventListener("rubani:session-expired", onExpired);
  }, []);

  if (!user) return <AuthScreen onAuthenticated={handleAuthenticated} notice={expiredMessage} />;

  const token = user.access_token;
  const isSysadmin = user.role === "sysadmin";
  const navigation = NAVIGATION.filter((item) => item.roles.includes(user.role));
  const current = navigation.find((item) => item.id === activePage) || navigation[0];
  const pages = {
    reports: <div className="page-padding reports-page-padding"><ReportsDashboard token={token} isSysadmin={isSysadmin} companyId={user.company_id} /></div>,
    companies: <CompaniesPage token={token} />,
    models: <ModelsPage token={token} />,
    databases: <DatabaseTypesPage token={token} />,
    settings: <CompanySettingsPage token={token} />,
    employees: <EmployeesPage user={user} />,
  };

  return (
    <main className="app-shell">
      <aside className="sidebar">
        <div className="sidebar-brand">Rubani-QA</div>
        {navigation.map((item) => (
          <button key={item.id} type="button" className={`navigation-link ${current?.id === item.id ? "selected" : ""}`} onClick={() => setActivePage(item.id)} aria-current={current?.id === item.id ? "page" : undefined}>
            <span className="navigation-icon"><NavigationIcon name={item.id} /></span>
            <span className="navigation-label">{item.label}</span>
          </button>
        ))}
      </aside>
      <section className="main-area">
        <header className="topbar">
          <h1>{current?.label || "Rubani"}</h1>
          <div className="topbar-actions">
            
            <AccountMenu user={user} onLogout={() => handleLogout()} />
          </div>
        </header>
        <div className="page-content">
          {!current && <div className="page-padding"><Alert type="error">Your account has no access to any workspace pages.</Alert></div>}
          {current?.id === "queries" && <ChatPage token={token} messages={messages} setMessages={setMessages} isSysadmin={isSysadmin} companyId={chatCompanyId} setCompanyId={setChatCompanyId} />}
          {current && current.id !== "queries" && (current.id === "reports" ? pages.reports : <div className="page-padding">{pages[current.id]}</div>)}
        </div>
      </section>
    </main>
  );
}

export default App;
